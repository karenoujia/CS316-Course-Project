import './components/stylesheets/App.css';
import NavRouter from './components/NavRouter';
import React, { Component } from 'react';

class App extends Component {

  render() {
    return (
      <div>
        <NavRouter />
      </div>
    );
  }
}

export default App;
