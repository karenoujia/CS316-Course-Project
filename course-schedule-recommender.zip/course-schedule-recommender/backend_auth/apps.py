from django.apps import AppConfig


class BackendAuthConfig(AppConfig):
    name = 'backend_auth'
